import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False


def calculate_flood_control_final_v4():
    print("=" * 60)
    print("【第5章 水库防洪调节计算 (标注自适应版)】")
    print("=" * 60)

    # ==========================================
    # 1. 基础数据
    # ==========================================
    Z_dead = 750.00
    Z_norm = 796.52  # 起调水位
    Z_weir = Z_norm  # 溢洪道堰顶
    Z_inlet = 722.00

    # 水位-库容曲线
    zv_data = [
        [728.56177, 376.76752], [738.35424, 864.97076], [747.05208, 1473.08356],
        [753.82694, 2161.13607], [758.56046, 2769.24888], [764.74362, 3622.89079],
        [771.04512, 4690.65693], [776.10407, 5589.97868], [781.31095, 6672.01977],
        [785.27527, 7585.61647], [788.58873, 8379.3036], [792.22763, 9415.66486],
        [796.31029, 10511.9809], [799.65334, 11579.74704], [802.64138, 12479.06879],
        [805.15606, 13318.43575], [807.3749, 14063.58806], [808.17368, 14354.79701]
    ]
    zv_df = pd.DataFrame(zv_data, columns=['Z', 'V'])
    v_to_z = interp1d(zv_df['V'], zv_df['Z'], kind='linear', fill_value="extrapolate")
    z_to_v = interp1d(zv_df['Z'], zv_df['V'], kind='linear', fill_value="extrapolate")

    # 库容基准
    V_norm_cap = float(z_to_v(Z_norm))
    V_dead_cap = float(z_to_v(Z_dead))

    # 洪水数据
    times = np.array([0, 12, 20, 26, 32, 39, 43, 46, 52, 55, 56, 59,
                      60, 63, 64, 65, 68, 72, 76, 80, 96, 105, 110])
    Q_check_data = np.array([60.0, 146, 190, 133, 101, 90.9, 321, 591, 651, 731, 740, 869,
                             1380, 2131, 3100, 2767, 1860, 1065, 570, 474, 268, 197, 60])
    Q_design_data = np.array([60.0, 124, 137, 96, 73, 67, 222, 409, 442, 495, 502, 756,
                              875, 1443, 2100, 1876, 1323, 743, 456, 389, 208, 165, 60])
    Q_fc_data = np.array([60.0, 99, 102, 71, 56, 50, 152, 279, 295, 331, 335, 650,
                          758, 966, 1400, 1253, 842, 487, 269, 235, 170, 128, 60])

    func_Q_design = interp1d(times, Q_design_data, kind='linear')
    func_Q_check = interp1d(times, Q_check_data, kind='linear')
    func_Q_fc = interp1d(times, Q_fc_data, kind='linear')

    # 泄流参数
    B_spill = 38.00;
    m_spill = 0.49

    MAX_TUNNEL_FLOW = 60.0

    # ==========================================
    # 2. 核心函数
    def get_outflow(Z):
        # 1. 溢洪道 (水位超过堰顶才出流)
        q_spill = 0.0
        if Z > Z_weir:
            H = Z - Z_weir
            q_spill = m_spill * B_spill * 4.429 * (H ** 1.5)

        # 2. 输水洞 (恒定限流 60)
        q_tun = 0.0
        if Z > Z_inlet:
            q_tun = MAX_TUNNEL_FLOW

        return q_spill + q_tun

    def route_flood_rk4(func_Q_in, label):
        dt = 0.1
        total_time = 110
        steps = int(total_time / dt)

        t_arr = np.linspace(0, total_time, steps + 1)
        Z_arr = np.zeros(steps + 1)
        Q_out_arr = np.zeros(steps + 1)
        Q_in_arr = np.zeros(steps + 1)

        Z_curr = Z_norm
        V_curr = float(z_to_v(Z_curr))

        Z_arr[0] = Z_curr
        Q_out_arr[0] = get_outflow(Z_curr)
        Q_in_arr[0] = func_Q_in(0)

        factor = 0.36

        for i in range(steps):
            t = t_arr[i]

            def deriv(t_val, V_val):
                z_val = float(v_to_z(V_val))
                q_in = float(func_Q_in(t_val))
                q_out = get_outflow(z_val)
                return (q_in - q_out) * factor

            k1 = deriv(t, V_curr)
            k2 = deriv(t + dt / 2, V_curr + dt * k1 / 2)
            k3 = deriv(t + dt / 2, V_curr + dt * k2 / 2)
            k4 = deriv(t + dt, V_curr + dt * k3)

            V_next = V_curr + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

            t_next = t_arr[i + 1]
            Z_next = float(v_to_z(V_next))

            V_curr = V_next
            Z_arr[i + 1] = Z_next
            Q_out_arr[i + 1] = get_outflow(Z_next)
            Q_in_arr[i + 1] = func_Q_in(t_next)

        # 寻找峰值
        idx_max_z = np.argmax(Z_arr)
        max_Z = Z_arr[idx_max_z]
        t_max_Z = t_arr[idx_max_z]

        idx_max_out = np.argmax(Q_out_arr)
        max_Q_out = Q_out_arr[idx_max_out]
        t_max_out = t_arr[idx_max_out]

        idx_max_in = np.argmax(Q_in_arr)
        max_Q_in = Q_in_arr[idx_max_in]
        t_max_in = t_arr[idx_max_in]

        results = np.column_stack((t_arr, Q_in_arr, Q_out_arr, Z_arr))
        return max_Z, t_max_Z, max_Q_out, t_max_out, max_Q_in, t_max_in, results

    # ==========================================
    # 3. 执行计算

    Z_fc, t_Z_fc, Q_out_fc, t_out_fc, Q_in_fc, t_in_fc, res_fc = route_flood_rk4(func_Q_fc, "P=5%")
    Z_ds, t_Z_ds, Q_out_ds, t_out_ds, Q_in_ds, t_in_ds, res_ds = route_flood_rk4(func_Q_design, "P=1%")
    Z_ck, t_Z_ck, Q_out_ck, t_out_ck, Q_in_ck, t_in_ck, res_ck = route_flood_rk4(func_Q_check, "P=0.1%")

    # ==========================================
    # 4.输出

    V_dead = V_dead_cap
    V_xingli = V_norm_cap - V_dead_cap

    # 库容计算 (V_max - V_start)
    V_fc_max = float(z_to_v(Z_fc))
    v_flood_ctrl = max(0, V_fc_max - V_norm_cap)  # 防洪库容

    V_ds_max = float(z_to_v(Z_ds))
    v_intercept = max(0, V_ds_max - V_norm_cap)  # 拦洪库容

    V_ck_max = float(z_to_v(Z_ck))
    v_regulate = max(0, V_ck_max - V_norm_cap)  # 调洪库容

    print("\n" + "=" * 80)
    print("【最终成果表】")
    print("特征水位(m)\t死水位\t正常蓄水位\t防洪限制水位\t防洪高水位\t设计洪水位\t校核洪水位")
    print(f"\t\t{Z_dead:.2f}\t{Z_norm:.2f}\t{Z_norm:.2f}\t\t{Z_fc:.2f}\t{Z_ds:.2f}\t{Z_ck:.2f}")
    print("-" * 80)
    print("特征库容(万m3)\t死库容\t兴利库容\t结合库容\t防洪库容\t拦洪库容\t调洪库容")
    print(f"\t\t{V_dead:.2f}\t{V_xingli:.2f}\t0.00\t\t{v_flood_ctrl:.2f}\t{v_intercept:.2f}\t{v_regulate:.2f}")
    print("=" * 80 + "\n")

    # ==========================================
    # 5. 绘图

    def plot_hydrograph_v4(results, title_str, filename, theme='blue',
                           max_in_val=0, max_in_t=0,
                           max_out_val=0, max_out_t=0,
                           max_z_val=0, max_z_t=0):

        t = results[:, 0];
        q_in = results[:, 1];
        q_out = results[:, 2];
        z_level = results[:, 3]

        if theme == 'blue':
            c_in, c_fill, c_out = '#1f77b4', '#a6cee3', '#ff7f0e'
        elif theme == 'red':
            c_in, c_fill, c_out = '#d62728', '#fb9a99', '#9467bd'
        else:
            c_in, c_fill, c_out = '#2ca02c', '#b2df8a', '#8c564b'
        c_z = 'black'

        fig, ax1 = plt.subplots(figsize=(12, 7), dpi=150)

        ln1 = ax1.plot(t, q_in, color=c_in, linestyle='--', linewidth=1.5, label='$Q_{in}$')
        ax1.fill_between(t, q_in, 0, color=c_fill, alpha=0.3)
        ln2 = ax1.plot(t, q_out, color=c_out, linestyle='-', linewidth=2.5, label='$Q_{out}$')

        # 设置Y轴范围，留足顶部空间给标注
        y_max_q = max(max_in_val, max_out_val) * 1.25  # 增加25%的头部空间
        ax1.set_ylim(0, y_max_q)

        ax1.set_xlabel('时间 (h)', fontsize=12, fontweight='bold')
        ax1.set_ylabel('流量 ($m^3/s$)', fontsize=12, fontweight='bold')
        ax1.grid(True, linestyle=':', alpha=0.6)

        ax2 = ax1.twinx()
        ln3 = ax2.plot(t, z_level, color=c_z, linestyle='-.', linewidth=2.0, label='$Z$')
        ax2.set_ylabel('水位 (m)', fontsize=12, fontweight='bold')

        # 设置水位轴范围
        z_range = np.max(z_level) - np.min(z_level)
        if z_range < 1: z_range = 1  # 避免范围过小
        ax2.set_ylim(np.min(z_level) - z_range * 0.1, np.max(z_level) + z_range * 0.4)

        bbox_props = dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.9)

        # ---------------- 标注 ----------------

        def get_text_pos(time_val, y_val, offset_x=15, offset_y=0):
            if time_val < 55:  # 左半边
                return (time_val + offset_x, y_val + offset_y)
            else:  # 右半边
                return (time_val - offset_x, y_val + offset_y)

        # 1. 最大入库
        xy_text_in = get_text_pos(max_in_t, max_in_val, offset_x=12)
        ax1.annotate(f'最大入库\n{max_in_val:.0f} $m^3/s$',
                     xy=(max_in_t, max_in_val), xytext=xy_text_in,
                     arrowprops=dict(arrowstyle="->", color=c_in),
                     color=c_in, fontweight='bold', bbox=bbox_props)

        # 2. 最大下泄
        offset_y_out = 0
        if abs(max_in_t - max_out_t) < 10:
            offset_y_out = -max_out_val * 0.15 # 往下错开

        xy_text_out = get_text_pos(max_out_t, max_out_val, offset_x=12, offset_y=offset_y_out)
        ax1.annotate(f'最大下泄\n{max_out_val:.0f} $m^3/s$',
                     xy=(max_out_t, max_out_val), xytext=xy_text_out,
                     arrowprops=dict(arrowstyle="->", color=c_out),
                     color=c_out, fontweight='bold', bbox=bbox_props)

        # 3. 最高水位 (始终在正上方，利用第二坐标轴的坐标系)
        ax2.annotate(f'最高水位\n{max_z_val:.2f} m',
                     xy=(max_z_t, max_z_val),
                     xytext=(max_z_t, max_z_val + z_range * 0.15), # 往上提15%
                     arrowprops=dict(arrowstyle="->", color='black'),
                     color='black', fontweight='bold', bbox=bbox_props, ha='center')

        lines = ln1 + ln2 + ln3;
        labels = [l.get_label() for l in lines]
        ax1.legend(lines, labels, loc='upper right', frameon=True, shadow=True)

        plt.title(title_str, fontsize=16, fontweight='bold', pad=15)
        plt.tight_layout()
        plt.savefig(filename)

    plot_hydrograph_v4(res_fc, f"防洪标准洪水调节过程线 (P=5%)\n防洪高水位: {Z_fc:.2f}m", "防洪标准_P5.png",
                       'green',
                       Q_in_fc, t_in_fc, Q_out_fc, t_out_fc, Z_fc, t_Z_fc)
    plot_hydrograph_v4(res_ds, f"设计洪水调节过程线 (P=1%)\n设计洪水位: {Z_ds:.2f}m", "设计洪水_P1.png",
                       'blue',
                       Q_in_ds, t_in_ds, Q_out_ds, t_out_ds, Z_ds, t_Z_ds)
    plot_hydrograph_v4(res_ck, f"校核洪水调节过程线 (P=0.1%)\n校核洪水位: {Z_ck:.2f}m", "校核洪水_P0.1.png",
                       'red',
                       Q_in_ck, t_in_ck, Q_out_ck, t_out_ck, Z_ck, t_Z_ck)


if __name__ == "__main__":
    calculate_flood_control_final_v4()