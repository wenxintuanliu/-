import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearson3
import os

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False


def frequency_analysis_only():
    # ==========================================
    # 1. 读取已保存的水利年度数据
    file_path = "D:\\py.works\\水文课设\\monthly_flow_water_year.csv"
    if not os.path.exists(file_path):
        print(f"错误：当前目录下未找到 {file_path}，请先运行数据处理代码生成该文件。")
        return

    df = pd.read_csv(file_path)

    # 准备加权天数 (对应列 Month_4 到 Month_3)
    # 顺序: 4月(30), 5月(31), 6月(30), 7月(31), 8月(31), 9月(30),
    #       10月(31), 11月(30), 12月(31), 1月(31), 2月(28), 3月(31)
    days_ordered = np.array([30, 31, 30, 31, 31, 30, 31, 30, 31, 31, 28, 31])
    total_days = 365

    # 计算水文站年平均流量 (加权平均)
    q_station_list = []
    for _, row in df.iterrows():
        flows = row[df.columns[1:]].values.astype(float)
        mean_q = np.sum(flows * days_ordered) / total_days
        q_station_list.append(mean_q)

    # ==========================================
    # 2. 坝址径流修正 & 经验频率
    K_area = 670.0 / 680.0
    q_dam = np.array(q_station_list) * K_area

    n = len(q_dam)
    q_sorted = np.sort(q_dam)[::-1]  # 从大到小排序
    rank = np.arange(1, n + 1)
    p_empirical = (rank / (n + 1)) * 100  # 百分比

    # ==========================================
    # 3. 统计参数计算 (三种 Cs)
    mean_val = np.mean(q_dam)
    std_val = np.std(q_dam, ddof=1)
    Cv = std_val / mean_val

    # (1) 矩法 Cs
    Cs_moment = np.sum((q_dam - mean_val) ** 3) / ((n - 1) * (n - 2) * std_val ** 3) * n

    # (2) 倍比 Cs (Cs = 2Cv)
    Cs_2Cv = 2.0 * Cv

    # (3) 优化适线法 Cs (遍历寻找最小均方误差)
    best_Cs = Cs_moment
    min_sse = float('inf')

    # 在 0.1 到 4.0 范围内遍历
    for test_cs in np.arange(0.1, 4.0, 0.01):
        # 计算该 Cs 下对应经验频率点的理论 Q 值
        kp_vals = pearson3.ppf(1 - p_empirical / 100, skew=test_cs)
        q_theo = mean_val * (1 + Cv * kp_vals)
        # 计算误差平方和
        sse = np.sum((q_sorted - q_theo) ** 2)
        if sse < min_sse:
            min_sse = sse
            best_Cs = test_cs
    print(f"最小均方误差 SSE = {min_sse:.2f}")
    Cs_opt = best_Cs

    print(f"【统计参数计算结果】")
    print(f"均值 Mean = {mean_val:.2f} m³/s")
    print(f"变差系数 Cv = {Cv:.2f}")
    print(f"Cs (矩法) = {Cs_moment:.2f}")
    print(f"Cs (2Cv) = {Cs_2Cv:.2f}")
    print(f"Cs (优化适线) = {Cs_opt:.2f} (最终采用)")

    # ==========================================
    # 4. 绘制频率曲线 (线性坐标)
    plt.figure(figsize=(10, 6), dpi=150)

    # 理论曲线数据点 (0.1% ~ 99.9%)
    p_line = np.linspace(0.1, 99.9, 500)

    # 计算三条曲线
    q_line_moment = mean_val * (1 + Cv * pearson3.ppf(1 - p_line / 100, skew=Cs_moment))
    q_line_2Cv = mean_val * (1 + Cv * pearson3.ppf(1 - p_line / 100, skew=Cs_2Cv))
    q_line_opt = mean_val * (1 + Cv * pearson3.ppf(1 - p_line / 100, skew=Cs_opt))

    # 绘图
    plt.scatter(p_empirical, q_sorted, color='black', marker='o', s=25, label='经验点据', zorder=10)
    plt.plot(p_line, q_line_moment, 'g--', linewidth=1.5, label=f'矩法 Cs={Cs_moment:.2f}')
    plt.plot(p_line, q_line_2Cv, 'b-.', linewidth=1.5, label=f'Cs=2Cv ({Cs_2Cv:.2f})')
    plt.plot(p_line, q_line_opt, 'r-', linewidth=2.5, label=f'优化适线 Cs={Cs_opt:.2f} (采用)')

    plt.title('坝址年径流频率曲线 (水利年度)', fontsize=14)
    plt.xlabel('频率 P (%)', fontsize=12)
    plt.ylabel('年平均流量 Q (m³/s)', fontsize=12)
    plt.xlim(0, 100)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend()

    plt.tight_layout()
    plt.savefig("坝址年径流频率曲线.png")
    print(f"【图】频率曲线已保存为坝址年径流频率曲线.png")
    plt.show()

    # ==========================================
    # 5. 输出指定频率的设计值
    target_freqs = [20, 25, 30, 50, 70, 75, 80, 85, 90, 95]

    print("\n" + "=" * 50)
    print(f"【设计年径流成果表】 (采用 Cs={Cs_opt:.2f})")
    print("=" * 50)
    print(f"{'频率 P(%)':<10} | {'设计流量 Qp (m³/s)':<20}")
    print("-" * 50)

    for p in target_freqs:
        kp = pearson3.ppf(1 - p / 100.0, skew=Cs_opt)
        qp = mean_val * (1 + Cv * kp)
        # 年径流量换算 (万m3)
        # wp = qp * 365 * 86400 / 10000.0
        print(f"{p:<10} | {qp:<20.2f}")
    print("=" * 50)


if __name__ == "__main__":
    frequency_analysis_only()