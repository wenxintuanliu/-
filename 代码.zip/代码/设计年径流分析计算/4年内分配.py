import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# ==========================================
# 0. 全局设置
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False


def design_monthly_distribution():
    # ==========================================
    # 1. 准备数据
    file_path = "monthly_flow_water_year.csv"
    if not os.path.exists(file_path):
        print(f"错误：找不到文件 {file_path}，请先运行之前的数据处理代码。")
        return

    # 读取水利年度数据 (列: Water_Year, Month_4 ... Month_3)
    df = pd.read_csv(file_path)

    # 定义月份天数 (对应列序: 4月, 5月... 3月)
    days_ordered = np.array([30, 31, 30, 31, 31, 30, 31, 30, 31, 31, 28, 31])
    total_days = 365

    # 坝址修正系数
    K_area = 670.0 / 680.0

    annual_means_dam = []
    years = []

    # 提取流量矩阵 (行: 年份, 列: 12个月)
    flow_matrix = df[df.columns[1:]].values

    for idx, row_flows in enumerate(flow_matrix):
        # 计算该年的加权平均 Q_station
        q_station = np.sum(row_flows * days_ordered) / total_days
        # 修正到坝址 Q_dam
        q_dam = q_station * K_area

        annual_means_dam.append(q_dam)
        years.append(int(df.iloc[idx]['Water_Year']))

    df_result = pd.DataFrame({
        'Year': years,
        'Q_dam_mean': annual_means_dam
    })

    # ==========================================
    # 2. 定义设计目标 (来自2.2节成果)

    design_targets = {
        'P=50%': 11.77,
        'P=75%': 9.05,
        'P=95%': 5.89
    }

    # ==========================================
    # 3. 挑选典型年 & 缩放计
    final_rows = []  # 用于保存结果表的所有行

    print("【典型年选择与缩放计算】")
    print("-" * 60)

    plot_data = {}  # 用于存作图数据 (只存最终设计值)

    for label, target_q in design_targets.items():
        # 3.1 寻找最接近的年份
        df_result['diff'] = abs(df_result['Q_dam_mean'] - target_q)
        best_year_row = df_result.sort_values('diff').iloc[0]
        typical_year = int(best_year_row['Year'])
        typical_q_dam = best_year_row['Q_dam_mean']

        # 3.2 计算缩放系数 K
        K_scale = target_q / typical_q_dam

        print(f"设计频率 {label}:")
        print(f"  - 设计流量: {target_q:.2f} m³/s")
        print(f"  - 典型年: {typical_year}年 (实测坝址 Q={typical_q_dam:.2f})")
        print(f"  - 缩放系数 K: {K_scale:.4f}")

        # 3.3 获取典型年数据并计算三套数据

        # A. 获取原始水文站流量
        row_idx = df[df['Water_Year'] == typical_year].index[0]
        raw_flows_station = flow_matrix[row_idx]
        mean_station = np.sum(raw_flows_station * days_ordered) / total_days

        # B. 计算坝址流量 (未缩放) = 水文站 * K_area
        raw_flows_dam = raw_flows_station * K_area
        mean_dam_raw = np.sum(raw_flows_dam * days_ordered) / total_days

        # C. 计算设计流量 (缩放后) = 坝址 * K_scale
        design_flows = raw_flows_dam * K_scale
        mean_design = np.sum(design_flows * days_ordered) / total_days  # 应该等于 target_q

        # 保存数据用于作图
        plot_data[label] = design_flows

        # 3.4 将三行数据添加到结果列表
        # 格式: [频率, 典型年, 缩放系数, 数据类型, 4月...3月, 年均]

        # 第一行: 水文站实测
        final_rows.append([
            label, typical_year, f"{K_scale:.3f}",
            "1_水文站实测",
            *[f"{x:.2f}" for x in raw_flows_station],
            f"{mean_station:.2f}"
        ])

        # 第二行: 坝址(未缩放)
        final_rows.append([
            label, typical_year, f"{K_scale:.3f}",
            "2_坝址(未缩放)",
            *[f"{x:.2f}" for x in raw_flows_dam],
            f"{mean_dam_raw:.2f}"
        ])

        # 第三行: 设计(缩放后)
        final_rows.append([
            label, typical_year, f"{K_scale:.3f}",
            "3_设计(缩放后)",
            *[f"{x:.2f}" for x in design_flows],
            f"{mean_design:.2f}"
        ])


    # ==========================================
    # 4. 保存结果表格

    cols = ['频率', '典型年', '缩放系数K', '数据类型',
            '4月', '5月', '6月', '7月', '8月', '9月',
            '10月', '11月', '12月', '1月', '2月', '3月', '年均流量']

    df_out = pd.DataFrame(final_rows, columns=cols)
    out_file = "设计年径流详细分配表.csv"
    df_out.to_csv(out_file, index=False, encoding='utf-8-sig')

    print("-" * 60)
    print(f"【成功】包含三级数据（水文站/坝址/设计）的详细表已保存为: {out_file}")
    print("预览前6行:")
    print(df_out[['频率', '数据类型', '年均流量']].head(6).to_string(index=False))

    # ==========================================
    # 5. 绘制设计过程线

    plt.figure(figsize=(12, 6), dpi=150)

    months = np.arange(1, 13)
    month_labels = [f"{i}月" for i in [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3]]

    markers = {'P=50%': 'o', 'P=75%': 's', 'P=95%': '^'}
    colors = {'P=50%': 'green', 'P=75%': 'orange', 'P=95%': 'red'}
    linestyles = {'P=50%': '--', 'P=75%': '-', 'P=95%': '-.'}

    for label, flows in plot_data.items():
        plt.plot(months, flows,
                 marker=markers[label], markersize=5,
                 color=colors[label], linestyle=linestyles[label], linewidth=1.5,
                 label=f"{label} (Q={design_targets[label]} m³/s)")

    plt.title('坝址设计年径流年内分配过程线 (水利年度)', fontsize=14)
    plt.xlabel('月份 (水利年)', fontsize=12)
    plt.ylabel('平均流量 Q (m³/s)', fontsize=12)
    plt.xticks(months, month_labels)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend()

    plot_file = "设计年径流分配曲线.png"
    plt.savefig(plot_file)
    print(f"【成功】过程线图已保存为: {plot_file}")
    plt.show()


if __name__ == "__main__":
    design_monthly_distribution()