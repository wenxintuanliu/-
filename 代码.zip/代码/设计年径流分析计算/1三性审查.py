import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# -------------------------- 设置中文字体 --------------------------
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示为方块的问题

# 1. 基础数据 (1951-2000)
years = np.arange(1951, 2001)
data_flow = np.array([
    15.90, 22.34, 10.74, 18.38, 15.42, 18.01, 13.02, 18.95, 8.76, 10.40,
    16.22, 11.90, 11.87, 19.39, 7.09, 6.79, 8.91, 10.09, 7.74, 12.89,
    8.86, 10.06, 8.12, 11.61, 16.46, 11.88, 7.24, 13.10, 7.96, 14.53,
    22.73, 12.85, 21.73, 16.82, 9.69, 10.17,
    12.95, 15.59, 14.10, 14.26, 8.46, 11.68, 11.35, 6.39, 5.41,
    7.30, 4.91, 13.51, 13.43, 7.32
])

# 2. 计算统计量
mean_val = np.mean(data_flow)
cumulative_flow = np.cumsum(data_flow)
window_size = 5
moving_avg = pd.Series(data_flow).rolling(window=window_size, center=True).mean()


# 图2-1：历年平均流量过程线
plt.figure(figsize=(10, 6), dpi=150)
plt.plot(years, data_flow, 'o-', color='black', linewidth=1, markersize=4, label='年平均流量')
plt.axhline(mean_val, color='red', linestyle='--', label=f'多年平均值 ({mean_val:.2f})')
plt.ylabel(r'流量 $Q$ ($m^3/s$)', fontsize=12)
plt.xlabel('年份', fontsize=12)
plt.title('水文站历年平均流量过程线', fontsize=14)
plt.grid(True, linestyle=':', alpha=0.6)
plt.legend()
plt.tight_layout()
plt.savefig('2-1_Process_Line.png') # 保存图片
plt.show()

# 图2-2：单累积曲线
plt.figure(figsize=(10, 6), dpi=150)
plt.plot(years, cumulative_flow, 'k.-', linewidth=1.5, label='累积流量')
plt.plot([years[0], years[-1]], [cumulative_flow[0], cumulative_flow[-1]], 'b--', alpha=0.6, label='理论均匀线')
plt.ylabel(r'累积年平均流量 $\sum Q$ ($m^3/s$)', fontsize=12)
plt.xlabel('年份', fontsize=12)
plt.title('水文站年径流单累积曲线', fontsize=14)
plt.legend()
plt.grid(True, linestyle=':', alpha=0.6)
plt.tight_layout()
plt.savefig('2-2_Mass_Curve.png') # 保存图片
plt.show()

# 图2-3：滑动平均过程线
plt.figure(figsize=(10, 6), dpi=150)
plt.plot(years, data_flow, color='lightgray', marker='.', linestyle='-', markersize=4, label='实测年流量')
plt.plot(years, moving_avg, color='black', linewidth=2, label=f'{window_size}年滑动平均')
plt.axhline(mean_val, color='red', linestyle='--', label='多年平均值')
plt.ylabel(r'流量 $Q$ ($m^3/s$)', fontsize=12)
plt.xlabel('年份', fontsize=12)
plt.title('水文站年径流滑动平均过程线', fontsize=14)
plt.legend()
plt.grid(True, linestyle=':', alpha=0.6)
plt.tight_layout()
plt.savefig('2-3_Moving_Avg.png') # 保存图片
plt.show()