import numpy as np


def calculate_dam_elevation():
    print("=" * 60)
    print("【第6章 大坝高程确定计算】")
    print("=" * 60)

    # ==========================================
    # 1. 输入数据
    Z_design_flood = 803.41  # 设计洪水位 (P=1%)
    Z_check_flood = 805.63  # 校核洪水位 (P=0.1%)

    # 基础参数
    V_avg_max = 18.0  # 多年平均最大风速 (m/s)
    D = 3.0  # 吹程 (km)
    K = 0.77  # 护坡系数
    slope_ratio = 1 / 3.0  # tan(alpha)

    # 安全超高 (三级重力坝标准)
    Delta_design = 0.4
    Delta_check = 0.3

    # ==========================================
    # 2. 计算函数
    # ==========================================
    def calc_wave_runup(V_wind):
        # 1. 计算浪高 hB = 0.0208 * V^(5/4) * D^(1/3)
        hB = 0.0208 * (V_wind ** 1.25) * (D ** (1 / 3.0))

        # 2. 计算爬高 h_lang = 3.2 * K * hB * tan(alpha)
        h_lang = 3.2 * K * hB * slope_ratio

        return hB, h_lang

    # ==========================================
    # 3. 执行计算
    # ==========================================

    # --- 工况一：设计工况 (P=1%) ---
    V_design = 1.5 * V_avg_max
    hB_1, h_lang_1 = calc_wave_runup(V_design)
    Z_dam_1 = Z_design_flood + h_lang_1 + Delta_design

    print(f"【工况一：设计工况 (P=1%)】")
    print(f"  - 设计风速 V: {V_design:.2f} m/s")
    print(f"  - 浪高 hB:    {hB_1:.3f} m")
    print(f"  - 浪爬高 h浪: {h_lang_1:.3f} m")
    print(f"  - 安全超高:   {Delta_design:.2f} m")
    print(f"  - 静水位:     {Z_design_flood:.2f} m")
    print(f"  -> 计算坝顶高程: {Z_dam_1:.3f} m")
    print("-" * 40)

    # --- 工况二：校核工况 (P=0.1%) ---
    V_check = V_avg_max
    hB_2, h_lang_2 = calc_wave_runup(V_check)
    Z_dam_2 = Z_check_flood + h_lang_2 + Delta_check

    print(f"【工况二：校核工况 (P=0.1%)】")
    print(f"  - 设计风速 V: {V_check:.2f} m/s")
    print(f"  - 浪高 hB:    {hB_2:.3f} m")
    print(f"  - 浪爬高 h浪: {h_lang_2:.3f} m")
    print(f"  - 安全超高:   {Delta_check:.2f} m")
    print(f"  - 静水位:     {Z_check_flood:.2f} m")
    print(f"  -> 计算坝顶高程: {Z_dam_2:.3f} m")
    print("-" * 40)

    # ==========================================
    # 4. 结论
    Z_final = max(Z_dam_1, Z_dam_2)
    print(f"【最终结论】")
    print(f"比较两种工况，大坝坝顶高程应取较大值：")
    print(f"Z_坝 = {Z_final:.3f} m")
    print(f"建议取整为: {np.ceil(Z_final * 10) / 10:.1f} m 或 {np.ceil(Z_final):.1f} m")


if __name__ == "__main__":
    calculate_dam_elevation()