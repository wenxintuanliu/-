import numpy as np
import pandas as pd
from scipy.interpolate import interp1d


def regulate_physical_strict_final():
    print("=" * 60)
    print("【水库兴利调节计算】")
    print("=" * 60)

    # ==========================================
    # 1. 基础数据
    # ==========================================
    zv_data = [
        [728.56177, 376.76752], [738.35424, 864.97076], [747.05208, 1473.08356],
        [753.82694, 2161.13607], [758.56046, 2769.24888], [764.74362, 3622.89079],
        [771.04512, 4690.65693], [776.10407, 5589.97868], [781.31095, 6672.01977],
        [785.27527, 7585.61647], [788.58873, 8379.3036], [792.22763, 9415.66486],
        [796.31029, 10511.9809], [799.65334, 11579.74704], [802.64138, 12479.06879],
        [805.15606, 13318.43575], [807.3749, 14063.58806], [808.17368, 14354.79701]
    ]
    zv_df = pd.DataFrame(zv_data, columns=['Z', 'V'])
    v_to_z = interp1d(zv_df['V'], zv_df['Z'], kind='linear', fill_value="extrapolate")
    z_to_v = interp1d(zv_df['Z'], zv_df['V'], kind='linear', fill_value="extrapolate")

    Z_dead = 750.00
    V_dead = float(z_to_v(Z_dead))
    evap_rate = 0.05
    leak_rate = 0.05
    days_in_month = np.array([30, 31, 30, 31, 31, 30, 31, 30, 31, 31, 28, 31])
    month_labels = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3]

    agri_demand = np.array([168, 510, 776, 1376, 1073, 1310, 496, 314, 331, 204, 320, 529])
    urban_demand = np.full(12, 15000.0 / 12.0)
    w_use_base = agri_demand + urban_demand

    raw_flows_1971 = np.array([12.12, 17.93, 11.01, 25.42, 7.45, 6.10, 12.73, 5.98, 2.17, 1.64, 1.41, 3.71])
    K_area = 670.0 / 680.0
    q_dam_1971 = raw_flows_1971 * K_area
    w_in = q_dam_1971 * (9.05 / (np.sum(q_dam_1971 * days_in_month) / 365.0)) * days_in_month * 86400 / 10000.0

    # ==========================================
    # 2. 迭代计算
    # ==========================================
    current_losses = np.zeros(12)
    all_iter_data = []
    max_iters = 0
    V_xingli_final = 0.0

    V_xingli_prev = 0.0

    for k in range(1, 20):
        suffix = f"({k})" if k > 0 else ""
        iter_key = f"第{k}次"

        # 1. 净余缺
        w_total_use = w_use_base + current_losses
        balance_net = w_in - w_total_use

        # 2. 逆序累加算兴利库容
        balance_double = np.tile(balance_net, 2)
        max_deficit = 0.0
        curr_def = 0.0
        for b in reversed(balance_double):
            if b < 0:
                curr_def += abs(b)
            else:
                curr_def -= b
            if curr_def < 0: curr_def = 0
            if curr_def > max_deficit: max_deficit = curr_def

        V_xingli_curr = max_deficit
        print(f"--- {iter_key} 迭代 ---")
        print(f"   算得兴利库容: {V_xingli_curr:.2f} (上次: {V_xingli_prev:.2f})")

        # 3. 逐月调节
        limit_lower = V_dead
        limit_upper = V_dead + V_xingli_curr
        current_V_actual = limit_lower

        v_avg_list = []
        row_data_list = []

        for i in range(12):
            v_end_theory = current_V_actual + balance_net[i]

            spill = 0.0
            if v_end_theory > limit_upper:
                spill = v_end_theory - limit_upper

            v_end_actual = 0.0
            if v_end_theory > limit_upper:
                v_end_actual = limit_upper
            elif v_end_theory < limit_lower:
                v_end_actual = limit_lower
            else:
                v_end_actual = v_end_theory

            v_avg = (current_V_actual + v_end_actual) / 2.0
            v_avg_list.append(v_avg)

            row_data = {
                '总损失': current_losses[i],
                '余缺水量': balance_net[i],
                '期初实际蓄水': current_V_actual,
                '月末理论蓄水': v_end_theory,
                '弃水量': spill,
                '月末实际蓄水': v_end_actual,
                '月平均蓄水量': v_avg
            }
            row_data_list.append(row_data)
            current_V_actual = v_end_actual

        # 4. 下轮损失
        v_avg_arr = np.array(v_avg_list)
        next_losses = (v_avg_arr * evap_rate) + (v_avg_arr * leak_rate)

        # 5. 存表 (列生成)
        if len(all_iter_data) == 0:
            for i in range(12):
                all_iter_data.append({'月份': month_labels[i], '来水量': w_in[i], '用水量': w_use_base[i]})
        for i in range(12):
            rd = row_data_list[i]
            ik = f"({iter_key})"
            all_iter_data[i][f'总损失{ik}'] = rd['总损失']
            all_iter_data[i][f'余缺水量{ik}'] = rd['余缺水量']
            all_iter_data[i][f'期初蓄水{ik}'] = rd['期初实际蓄水']
            all_iter_data[i][f'月末蓄水(理论){ik}'] = rd['月末理论蓄水']
            all_iter_data[i][f'弃水量{ik}'] = rd['弃水量']
            all_iter_data[i][f'月末蓄水(实际){ik}'] = rd['月末实际蓄水']
            all_iter_data[i][f'月平均蓄水量{ik}'] = rd['月平均蓄水量']

        # ========================================================
        # 6. 收敛判定 (兴利库容差值 < 0.1)

        if k > 1:
            diff_v = abs(V_xingli_curr - V_xingli_prev)
            print(f"   -> 库容差值: {diff_v:.4f} (阈值 0.1)")

            if diff_v < 0.1:
                print(f"   -> 【收敛成功】")
                max_iters = k
                V_xingli_final = V_xingli_curr
                break

        # 没收敛，更新状态进入下一轮
        current_losses = next_losses
        V_xingli_prev = V_xingli_curr  # 更新上一次的库容记录
        max_iters = k
        V_xingli_final = V_xingli_curr

    # ==========================================
    # 3. 导出
    cols = ['月份', '来水量', '用水量']
    for k in range(1, max_iters + 1):
        ik = f"(第{k}次)"
        cols.extend([
            f'总损失{ik}', f'余缺水量{ik}',
            f'期初蓄水{ik}', f'月末蓄水(理论){ik}', f'弃水量{ik}', f'月末蓄水(实际){ik}',
            f'月平均蓄水量{ik}'
        ])

    df_out = pd.DataFrame(all_iter_data)
    df_out = df_out[cols]
    filename = "水库兴利调节计算.csv"
    df_out.round(2).to_csv(filename, index=False, encoding='utf-8-sig')

    print("-" * 60)
    print(f"最终兴利库容: {V_xingli_final:.2f} 万m³")
    Z_normal = float(v_to_z(V_dead + V_xingli_final))
    print(f"正常蓄水位:   {Z_normal:.2f} m")
    print(f"文件已生成:   {filename}")


if __name__ == "__main__":
    regulate_physical_strict_final()