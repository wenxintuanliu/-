import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ==========================================
# 0. 全局设置
# ==========================================
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False


def analyze_design_flood():
    print("=" * 60)
    print("【第3章 设计洪水分析成果生成】")
    print("=" * 60)

    # ==========================================
    # 1. 录入表10数据 (设计洪水过程线)
    # 时间节点 (h)
    time_points = [0, 12, 20, 26, 32, 39, 43, 46, 52, 55, 56, 59,
                   60, 63, 64, 65, 68, 72, 76, 80, 96, 105, 110]

    # 流量数据 (m3/s)
    # P=0.1% (校核)
    q_0p1 = [60.0, 146, 190, 133, 101, 90.9, 321, 591, 651, 731, 740, 869,
             1380, 2131, 3100, 2767, 1860, 1065, 570, 474, 268, 197, 60]

    # P=1% (设计)
    q_1p0 = [60.0, 124, 137, 96, 73, 67, 222, 409, 442, 495, 502, 756,
             875, 1443, 2100, 1876, 1323, 743, 456, 389, 208, 165, 60]

    # P=5% (平水/丰水参考)
    q_5p0 = [60.0, 99, 102, 71, 56, 50, 152, 279, 295, 331, 335, 650,
             758, 966, 1400, 1253, 842, 487, 269, 235, 170, 128, 60]

    # 创建DataFrame
    df_flood = pd.DataFrame({
        'Time(h)': time_points,
        'Q_0.1%': q_0p1,
        'Q_1%': q_1p0,
        'Q_5%': q_5p0
    })

    # ==========================================
    # 2. 绘制设计洪水过程线图
    # ==========================================
    plt.figure(figsize=(12, 7), dpi=150)

    # 绘制三条曲线
    plt.plot(df_flood['Time(h)'], df_flood['Q_0.1%'], 'r-o', markersize=4, linewidth=2, label='P=0.1% (校核洪水)')
    plt.plot(df_flood['Time(h)'], df_flood['Q_1%'], 'b-s', markersize=4, linewidth=2, label='P=1% (设计洪水)')
    plt.plot(df_flood['Time(h)'], df_flood['Q_5%'],
             color='green', marker='^', linestyle='--',
             markersize=4, linewidth=1.5, label='P=5%')

    # 标注峰值
    peak_0p1 = max(q_0p1)
    peak_time_0p1 = time_points[q_0p1.index(peak_0p1)]
    plt.text(peak_time_0p1, peak_0p1 + 50, f'Qmax={peak_0p1}', ha='center', fontsize=10, color='red')

    peak_1p0 = max(q_1p0)
    peak_time_1p0 = time_points[q_1p0.index(peak_1p0)]
    plt.text(peak_time_1p0, peak_1p0 + 50, f'Qmax={peak_1p0}', ha='center', fontsize=10, color='blue')

    peak_5p0 = max(q_5p0)
    peak_time_5p0 = time_points[q_5p0.index(peak_5p0)]
    plt.text(peak_time_5p0, peak_5p0 + 50, f'Qmax={peak_5p0}', ha='center', fontsize=10, color='green')

    # 图表设置
    plt.title('坝址设计洪水过程线图', fontsize=16)
    plt.xlabel('时间 (h)', fontsize=12)
    plt.ylabel('流量 Q (m³/s)', fontsize=12)
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend()

    # 保存图片
    plot_file = "设计洪水过程线.png"
    plt.savefig(plot_file)
    print(f"【成功】设计洪水过程线图已保存为: {plot_file}")
    plt.show()

    # ==========================================
    # 3. 生成洪峰洪量成果表 (对应表9)

    print("\n【3.2 设计洪峰流量及洪量成果 (引用表9)】")
    print("-" * 50)
    print(f"{'项目':<15} | {'P=0.1% (校核)':<15} | {'P=1% (设计)':<15}")
    print("-" * 50)
    print(f"{'洪峰 Qm (m³/s)':<15} | {'3100':<15} | {'2100':<15}")
    print(f"{'24h洪量 (万m³)':<15} | {'11191':<15} | {'7578':<15}")
    print(f"{'72h洪量 (万m³)':<15} | {'17381':<15} | {'11913':<15}")
    print("-" * 50)

if __name__ == "__main__":
    analyze_design_flood()